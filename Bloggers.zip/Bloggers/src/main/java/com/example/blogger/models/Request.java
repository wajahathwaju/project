package com.example.blogger.models;

import com.example.blogger.entities.Blogger;

public class Request {
	private String title;
	private String body;
	private String summary;
	
	
	public Blogger toblogger() {
		Blogger blog=new Blogger();
		blog.setTitle(title);
		blog.setBody(body);
		blog.setSummary(summary);
		return blog;
	}
	
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	public String getSummary() {
		return summary;
	}
	public void setSummary(String summary) {
		this.summary = summary;
	}
	@Override
	public String toString() {
		return "Request [title=" + title + ", body=" + body + ", summary=" + summary + "]";
	}
	
}
