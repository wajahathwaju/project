package com.example.blogger.models;

import java.util.List;

import com.example.blogger.entities.Blogger;

public class ResponseList {
	public String message;
	public List<Blogger> blogger;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public List<Blogger> getBlogger() {
		return blogger;
	}
	public void setBlogger(List<Blogger> blogger) {
		this.blogger = blogger;
	}
	@Override
	public String toString() {
		return "RequestList [message=" + message + ", blogger=" + blogger + "]";
	}
	
}
