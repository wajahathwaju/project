package com.example.blogger.repositories;

import org.springframework.data.repository.CrudRepository;

import com.example.blogger.entities.Blogger;

public interface Repository extends CrudRepository<Blogger,Long>{

}
