package com.example.blogger.services;

import java.util.List;

import com.example.blogger.entities.Blogger;

public interface BloggerService {
	public List<Blogger> getAll();

	public Blogger get(Long id);

	public Blogger put(Blogger blogger);

	public Blogger update(Long id, Blogger Blogger);

	public Blogger delete(Long id);

}
